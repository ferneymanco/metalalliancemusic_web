import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-GLKVLV4U.js";
import "./chunk-KRVPCK3J.js";
import "./chunk-JJTKTLH6.js";
import "./chunk-MYH662QH.js";
import "./chunk-LKDWXENB.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
//# sourceMappingURL=@angular_cdk_text-field.js.map
