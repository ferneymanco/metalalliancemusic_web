import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-ITO7J5LF.js";
import "./chunk-GLKVLV4U.js";
import "./chunk-IQ2BY3RQ.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-AG7HUSEX.js";
import "./chunk-QQMB4HLI.js";
import "./chunk-CWPBPKTY.js";
import "./chunk-KRVPCK3J.js";
import "./chunk-JJTKTLH6.js";
import "./chunk-MYH662QH.js";
import "./chunk-LKDWXENB.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
