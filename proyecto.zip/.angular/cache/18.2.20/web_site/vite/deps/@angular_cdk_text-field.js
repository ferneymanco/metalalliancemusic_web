import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-KEBQDE4Y.js";
import "./chunk-ISGUJY53.js";
import "./chunk-L6AVHC25.js";
import "./chunk-NNNLFTTJ.js";
import "./chunk-KTESVR3Q.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
//# sourceMappingURL=@angular_cdk_text-field.js.map
