export const environment = {
    production: true,
    firebaseConfig: {
        apiKey: "AIzaSyDRaQE4eKJn-urFM01rssyNKzAedo-fW5Q",
        authDomain: "metalalliancemusic.firebaseapp.com",
        projectId: "metalalliancemusic",
        storageBucket: "metalalliancemusic.firebasestorage.app",
        messagingSenderId: "448270506097",
        appId: "1:448270506097:web:e4ee4cb3c17110184ea3d0"
        }
};
