import { SafeHtml } from "@angular/platform-browser";

export interface  Efemerides{
    title: string;
    date: string;
    description: SafeHtml;
}